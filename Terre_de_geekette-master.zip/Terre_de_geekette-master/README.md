# Terre_de_geekette
premier site web en HTML5 et en CSS3

Le site est constitué de quatre pages :  
 
- Page d'accueil
- page article
- page mentions légales
- page présentation de l'entreprise  
  

De nouvelles pages ont été ajoutées :  

- Page contenant un formulaire --> Contact
- Page Prestation contenant un tableau  
  
Le responsive est encore en cours..

Merci pour votre visite

[Laurina Toussaint](laurinatoussaint@gmail.com)
